<template>
  <div id="centerRight1">
    <div class="bg-color-black">
      <div class="d-flex pt-2 pl-2">
        <span style="color:#5cd9e8">
          <icon name="chart-line"></icon>
        </span>
        <div class="d-flex">
          <span class="fs-xl text mx-2">任务完成排行榜</span>
        </div>
      </div>
      <div class="d-flex jc-center body-box">
        <dv-scroll-board :config="config" style="width:3.375rem;height:4.28rem" />
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      config: {
        header: ["组件", "分支", "覆盖率"],
        data: [
          ["机修", "dev-1", "<span  class='colorGrass'>↑75%</span>"],
          ["钢筋", "dev-2", "<span  class='colorRed'>↓33%</span>"],
          ["泥水", "dev-3", "<span  class='colorGrass'>↑100%</span>"],
          ["砖瓦", "rea-1", "<span  class='colorGrass'>↑94%</span>"],
          ["抹灰", "rea-2", "<span  class='colorGrass'>↑95%</span>"],
          ["涂料", "fix-2", "<span  class='colorGrass'>↑63%</span>"],
          ["装饰", "fix-4", "<span  class='colorGrass'>↑84%</span>"],
          ["电力", "fix-7", "<span  class='colorRed'>↓46%</span>"],
          ["水暖", "dev-2", "<span  class='colorRed'>↓13%</span>"],
          ["机械", "dev-9", "<span  class='colorGrass'>↑76%</span>"]
        ],
        rowNum: 7, //表格行数
        headerHeight: 35,
        headerBGC: "#0f1325", //表头
        oddRowBGC: "#0f1325", //奇数行
        evenRowBGC: "#171c33", //偶数行
        index: true,
        columnWidth: [50],
        align: ["center"]
      }
    };
  },
  components: {},
  mounted() {},
  methods: {}
};
</script>

<style lang="scss">
#centerRight1 {
  padding: 0.2rem;
  height: 5.125rem;
  min-width: 3.75rem;
  border-radius: 0.0625rem;
  .bg-color-black {
    height: 4.8125rem;
    border-radius: 0.125rem;
  }
  .text {
    color: #c3cbde;
  }
  .body-box {
    border-radius: 0.125rem;
    overflow: hidden;
  }
}
</style>
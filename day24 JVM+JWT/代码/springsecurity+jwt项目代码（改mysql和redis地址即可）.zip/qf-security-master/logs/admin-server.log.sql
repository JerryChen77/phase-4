2021-07-31 15:20:16,893 [http-nio-8080-exec-9] ==>  Preparing: select * from sys_user t where t.username = ? 
2021-07-31 15:20:16,902 [http-nio-8080-exec-9] ==> Parameters: admin(String)
2021-07-31 15:20:16,916 [http-nio-8080-exec-9] <==      Total: 1
2021-07-31 15:20:16,923 [http-nio-8080-exec-9] ==>  Preparing: select distinct p.* from sys_permission p inner join sys_role_permission rp on p.id = rp.permissionId inner join sys_role_user ru on ru.roleId = rp.roleId where ru.userId = ? order by p.sort 
2021-07-31 15:20:16,926 [http-nio-8080-exec-9] ==> Parameters: 1(Long)
2021-07-31 15:20:16,940 [http-nio-8080-exec-9] <==      Total: 22
2021-07-31 15:20:17,063 [taskExecutor-1] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-07-31 15:20:17,069 [taskExecutor-1] ==> Parameters: 1(Long), 登陆(String), true(Boolean), null
2021-07-31 15:20:17,075 [taskExecutor-1] <==    Updates: 1
2021-07-31 15:20:17,240 [http-nio-8080-exec-2] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-07-31 15:20:17,242 [http-nio-8080-exec-2] ==> Parameters: 1(Long)
2021-07-31 15:20:17,250 [http-nio-8080-exec-2] <==      Total: 1
2021-07-31 15:20:40,235 [http-nio-8080-exec-3] ==>  Preparing: select count(1) from sys_role t 
2021-07-31 15:20:40,236 [http-nio-8080-exec-3] ==> Parameters: 
2021-07-31 15:20:40,241 [http-nio-8080-exec-3] <==      Total: 1
2021-07-31 15:20:40,244 [http-nio-8080-exec-3] ==>  Preparing: select * from sys_role t order by updateTime desc limit ?, ? 
2021-07-31 15:20:40,247 [http-nio-8080-exec-3] ==> Parameters: 0(Integer), 10(Integer)
2021-07-31 15:20:40,250 [http-nio-8080-exec-3] <==      Total: 2
2021-07-31 15:20:52,855 [http-nio-8080-exec-8] ==>  Preparing: select * from sys_permission t order by t.sort 
2021-07-31 15:20:52,856 [http-nio-8080-exec-8] ==> Parameters: 
2021-07-31 15:20:52,859 [http-nio-8080-exec-8] <==      Total: 22
2021-07-31 15:20:52,890 [http-nio-8080-exec-10] ==>  Preparing: select * from sys_role t where t.id = ? 
2021-07-31 15:20:52,891 [http-nio-8080-exec-10] ==> Parameters: 1(Long)
2021-07-31 15:20:52,892 [http-nio-8080-exec-10] <==      Total: 1
2021-07-31 15:20:52,904 [http-nio-8080-exec-4] ==>  Preparing: select p.* from sys_permission p inner join sys_role_permission rp on p.id = rp.permissionId where rp.roleId = ? order by p.sort 
2021-07-31 15:20:52,905 [http-nio-8080-exec-4] ==> Parameters: 1(Long)
2021-07-31 15:20:52,909 [http-nio-8080-exec-4] <==      Total: 22
2021-07-31 15:21:14,295 [http-nio-8080-exec-10] ==>  Preparing: select count(1) from sys_role t 
2021-07-31 15:21:14,296 [http-nio-8080-exec-10] ==> Parameters: 
2021-07-31 15:21:14,297 [http-nio-8080-exec-10] <==      Total: 1
2021-07-31 15:21:14,298 [http-nio-8080-exec-10] ==>  Preparing: select * from sys_role t order by updateTime desc limit ?, ? 
2021-07-31 15:21:14,299 [http-nio-8080-exec-10] ==> Parameters: 0(Integer), 10(Integer)
2021-07-31 15:21:14,301 [http-nio-8080-exec-10] <==      Total: 2
2021-07-31 15:21:22,798 [http-nio-8080-exec-1] ==>  Preparing: select * from sys_permission t order by t.sort 
2021-07-31 15:21:22,798 [http-nio-8080-exec-1] ==> Parameters: 
2021-07-31 15:21:22,801 [http-nio-8080-exec-1] <==      Total: 22
2021-07-31 15:22:12,068 [http-nio-8080-exec-5] ==>  Preparing: select * from sys_permission t order by t.sort 
2021-07-31 15:22:12,069 [http-nio-8080-exec-5] ==> Parameters: 
2021-07-31 15:22:12,071 [http-nio-8080-exec-5] <==      Total: 22
2021-07-31 15:22:12,090 [http-nio-8080-exec-2] ==>  Preparing: select * from sys_role t where t.id = ? 
2021-07-31 15:22:12,090 [http-nio-8080-exec-2] ==> Parameters: 1(Long)
2021-07-31 15:22:12,091 [http-nio-8080-exec-2] <==      Total: 1
2021-07-31 15:22:12,101 [http-nio-8080-exec-3] ==>  Preparing: select p.* from sys_permission p inner join sys_role_permission rp on p.id = rp.permissionId where rp.roleId = ? order by p.sort 
2021-07-31 15:22:12,102 [http-nio-8080-exec-3] ==> Parameters: 1(Long)
2021-07-31 15:22:12,105 [http-nio-8080-exec-3] <==      Total: 22
2021-07-31 15:25:27,782 [http-nio-8080-exec-6] ==>  Preparing: select count(1) from file_info t 
2021-07-31 15:25:27,784 [http-nio-8080-exec-6] ==> Parameters: 
2021-07-31 15:25:27,790 [http-nio-8080-exec-6] <==      Total: 1
2021-07-31 15:26:03,354 [http-nio-8080-exec-7] ==>  Preparing: select count(1) from sys_role t 
2021-07-31 15:26:03,355 [http-nio-8080-exec-7] ==> Parameters: 
2021-07-31 15:26:03,359 [http-nio-8080-exec-7] <==      Total: 1
2021-07-31 15:26:03,361 [http-nio-8080-exec-7] ==>  Preparing: select * from sys_role t order by updateTime desc limit ?, ? 
2021-07-31 15:26:03,362 [http-nio-8080-exec-7] ==> Parameters: 0(Integer), 10(Integer)
2021-07-31 15:26:03,364 [http-nio-8080-exec-7] <==      Total: 2
2021-07-31 15:27:54,432 [http-nio-8080-exec-9] ==>  Preparing: select * from sys_user t where t.username = ? 
2021-07-31 15:27:54,433 [http-nio-8080-exec-9] ==> Parameters: admin(String)
2021-07-31 15:27:54,434 [http-nio-8080-exec-9] <==      Total: 1
2021-07-31 15:27:54,435 [http-nio-8080-exec-9] ==>  Preparing: select distinct p.* from sys_permission p inner join sys_role_permission rp on p.id = rp.permissionId inner join sys_role_user ru on ru.roleId = rp.roleId where ru.userId = ? order by p.sort 
2021-07-31 15:27:54,435 [http-nio-8080-exec-9] ==> Parameters: 1(Long)
2021-07-31 15:27:54,437 [http-nio-8080-exec-9] <==      Total: 22
2021-07-31 15:27:54,521 [taskExecutor-2] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-07-31 15:27:54,521 [taskExecutor-2] ==> Parameters: 1(Long), 登陆(String), true(Boolean), null
2021-07-31 15:27:54,523 [taskExecutor-2] <==    Updates: 1
2021-07-31 15:27:54,618 [http-nio-8080-exec-3] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-07-31 15:27:54,619 [http-nio-8080-exec-3] ==> Parameters: 1(Long)
2021-07-31 15:27:54,620 [http-nio-8080-exec-3] <==      Total: 1
2021-07-31 15:27:59,558 [http-nio-8080-exec-10] ==>  Preparing: select count(1) from file_info t 
2021-07-31 15:27:59,558 [http-nio-8080-exec-10] ==> Parameters: 
2021-07-31 15:27:59,559 [http-nio-8080-exec-10] <==      Total: 1
2021-07-31 15:28:03,457 [http-nio-8080-exec-9] ==>  Preparing: select * from sys_permission t order by t.sort 
2021-07-31 15:28:03,458 [http-nio-8080-exec-9] ==> Parameters: 
2021-07-31 15:28:03,460 [http-nio-8080-exec-9] <==      Total: 22
2021-07-31 15:28:10,603 [http-nio-8080-exec-6] ==>  Preparing: select count(1) from sys_role t 
2021-07-31 15:28:10,604 [http-nio-8080-exec-6] ==> Parameters: 
2021-07-31 15:28:10,606 [http-nio-8080-exec-6] <==      Total: 1
2021-07-31 15:28:10,607 [http-nio-8080-exec-6] ==>  Preparing: select * from sys_role t order by updateTime desc limit ?, ? 
2021-07-31 15:28:10,608 [http-nio-8080-exec-6] ==> Parameters: 0(Integer), 10(Integer)
2021-07-31 15:28:10,610 [http-nio-8080-exec-6] <==      Total: 2
2021-07-31 15:28:33,984 [taskExecutor-3] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-07-31 15:28:33,984 [taskExecutor-3] ==> Parameters: 1(Long), 退出(String), true(Boolean), null
2021-07-31 15:28:33,985 [taskExecutor-3] <==    Updates: 1
2021-07-31 15:28:38,564 [http-nio-8080-exec-3] ==>  Preparing: select * from sys_user t where t.username = ? 
2021-07-31 15:28:38,565 [http-nio-8080-exec-3] ==> Parameters: user(String)
2021-07-31 15:28:38,566 [http-nio-8080-exec-3] <==      Total: 1
2021-07-31 15:28:38,568 [http-nio-8080-exec-3] ==>  Preparing: select distinct p.* from sys_permission p inner join sys_role_permission rp on p.id = rp.permissionId inner join sys_role_user ru on ru.roleId = rp.roleId where ru.userId = ? order by p.sort 
2021-07-31 15:28:38,569 [http-nio-8080-exec-3] ==> Parameters: 2(Long)
2021-07-31 15:28:38,570 [http-nio-8080-exec-3] <==      Total: 17
2021-07-31 15:28:38,656 [taskExecutor-4] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-07-31 15:28:38,656 [taskExecutor-4] ==> Parameters: 2(Long), 登陆(String), true(Boolean), null
2021-07-31 15:28:38,658 [taskExecutor-4] <==    Updates: 1
2021-07-31 15:28:38,748 [http-nio-8080-exec-1] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-07-31 15:28:38,748 [http-nio-8080-exec-1] ==> Parameters: 2(Long)
2021-07-31 15:28:38,750 [http-nio-8080-exec-1] <==      Total: 1
2021-07-31 15:28:49,299 [taskExecutor-5] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-07-31 15:28:49,299 [taskExecutor-5] ==> Parameters: 2(Long), 退出(String), true(Boolean), null
2021-07-31 15:28:49,301 [taskExecutor-5] <==    Updates: 1
2021-07-31 15:28:55,884 [http-nio-8080-exec-1] ==>  Preparing: select * from sys_user t where t.username = ? 
2021-07-31 15:28:55,885 [http-nio-8080-exec-1] ==> Parameters: admin(String)
2021-07-31 15:28:55,886 [http-nio-8080-exec-1] <==      Total: 1
2021-07-31 15:28:55,886 [http-nio-8080-exec-1] ==>  Preparing: select distinct p.* from sys_permission p inner join sys_role_permission rp on p.id = rp.permissionId inner join sys_role_user ru on ru.roleId = rp.roleId where ru.userId = ? order by p.sort 
2021-07-31 15:28:55,887 [http-nio-8080-exec-1] ==> Parameters: 1(Long)
2021-07-31 15:28:55,888 [http-nio-8080-exec-1] <==      Total: 22
2021-07-31 15:28:55,971 [taskExecutor-6] ==>  Preparing: insert into sys_logs(userId, module, flag, remark, createTime) values(?, ?, ?, ?, now()) 
2021-07-31 15:28:55,972 [taskExecutor-6] ==> Parameters: 1(Long), 登陆(String), true(Boolean), null
2021-07-31 15:28:55,973 [taskExecutor-6] <==    Updates: 1
2021-07-31 15:28:56,072 [http-nio-8080-exec-2] ==>  Preparing: select count(1) from t_notice t left join t_notice_read r on r.noticeId = t.id and r.userId = ? where t.status = 1 and r.userId is null 
2021-07-31 15:28:56,073 [http-nio-8080-exec-2] ==> Parameters: 1(Long)
2021-07-31 15:28:56,074 [http-nio-8080-exec-2] <==      Total: 1
2021-07-31 15:58:34,630 [http-nio-8080-exec-9] ==>  Preparing: select count(1) from file_info t 
2021-07-31 15:58:34,634 [http-nio-8080-exec-9] ==> Parameters: 
2021-07-31 15:58:34,635 [http-nio-8080-exec-9] <==      Total: 1
2021-07-31 16:05:26,047 [http-nio-8080-exec-10] ==>  Preparing: select count(1) from sys_role t 
2021-07-31 16:05:26,048 [http-nio-8080-exec-10] ==> Parameters: 
2021-07-31 16:05:26,050 [http-nio-8080-exec-10] <==      Total: 1
2021-07-31 16:05:26,053 [http-nio-8080-exec-10] ==>  Preparing: select * from sys_role t order by updateTime desc limit ?, ? 
2021-07-31 16:05:26,054 [http-nio-8080-exec-10] ==> Parameters: 0(Integer), 10(Integer)
2021-07-31 16:05:26,056 [http-nio-8080-exec-10] <==      Total: 2
2021-07-31 16:08:54,756 [http-nio-8080-exec-6] ==>  Preparing: select count(1) from sys_role t 
2021-07-31 16:08:54,757 [http-nio-8080-exec-6] ==> Parameters: 
2021-07-31 16:08:54,759 [http-nio-8080-exec-6] <==      Total: 1
2021-07-31 16:08:54,762 [http-nio-8080-exec-6] ==>  Preparing: select * from sys_role t order by updateTime desc limit ?, ? 
2021-07-31 16:08:54,763 [http-nio-8080-exec-6] ==> Parameters: 0(Integer), 10(Integer)
2021-07-31 16:08:54,764 [http-nio-8080-exec-6] <==      Total: 2
2021-07-31 16:08:55,176 [http-nio-8080-exec-5] ==>  Preparing: select * from sys_permission t order by t.sort 
2021-07-31 16:08:55,177 [http-nio-8080-exec-5] ==> Parameters: 
2021-07-31 16:08:55,179 [http-nio-8080-exec-5] <==      Total: 22
2021-07-31 16:08:56,013 [http-nio-8080-exec-1] ==>  Preparing: select count(1) from file_info t 
2021-07-31 16:08:56,014 [http-nio-8080-exec-1] ==> Parameters: 
2021-07-31 16:08:56,015 [http-nio-8080-exec-1] <==      Total: 1
